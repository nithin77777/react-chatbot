import { createChatBotMessage } from 'react-chatbot-kit';

export const botName = 'Infinity Bot';
const config = {
  botName: botName,
  initialMessages: [
    createChatBotMessage(
      `Hi this is ${botName}. Please Help me with your name.`
    ),
  ],
  customStyles: {
    
  },
};

export default config;
