import React from 'react';
import config from './config';


const ActionProvider = ({ createChatBotMessage, setState, children }) => {
  const forHello = () => {
    const botMessage = createChatBotMessage(
      `Hello, this is ${config.botName} ! How Can I Help you`
    );
    let state=setState(prev => ({
      ...prev,
      messages: [...prev.messages, botMessage   ],
    }));
    console.log(state);
  };

  return (
    <div>
      {React.Children.map(children, child => {
        return React.cloneElement(child, {
          actions: {
            forHello,
            
          },
        });
      })}
    </div>
  );
};

export default ActionProvider;
